﻿namespace tugas_W05
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_Product = new System.Windows.Forms.Label();
            this.lb_Category = new System.Windows.Forms.Label();
            this.lb_Detail = new System.Windows.Forms.Label();
            this.dataGridView_Product = new System.Windows.Forms.DataGridView();
            this.dataGridView_Category = new System.Windows.Forms.DataGridView();
            this.lb_NamaDetails = new System.Windows.Forms.Label();
            this.lb_CategoryDetails = new System.Windows.Forms.Label();
            this.lb_HargaDetails = new System.Windows.Forms.Label();
            this.lb_StockDetails = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tb_NamaDetail = new System.Windows.Forms.TextBox();
            this.tb_HargaDetails = new System.Windows.Forms.TextBox();
            this.tb_StockDetails = new System.Windows.Forms.TextBox();
            this.comboBox_CategoryDetails = new System.Windows.Forms.ComboBox();
            this.tb_NamaCategory = new System.Windows.Forms.TextBox();
            this.comboBox_Filter = new System.Windows.Forms.ComboBox();
            this.bt_Filter = new System.Windows.Forms.Button();
            this.bt_All = new System.Windows.Forms.Button();
            this.bt_AddProduct = new System.Windows.Forms.Button();
            this.bt_EditProduct = new System.Windows.Forms.Button();
            this.bt_RemoveProduct = new System.Windows.Forms.Button();
            this.bt_AddCategory = new System.Windows.Forms.Button();
            this.bt_RemoveCategory = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lb_Product
            // 
            this.lb_Product.AutoSize = true;
            this.lb_Product.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Product.Location = new System.Drawing.Point(27, 9);
            this.lb_Product.Name = "lb_Product";
            this.lb_Product.Size = new System.Drawing.Size(119, 32);
            this.lb_Product.TabIndex = 0;
            this.lb_Product.Text = "Product";
            // 
            // lb_Category
            // 
            this.lb_Category.AutoSize = true;
            this.lb_Category.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Category.Location = new System.Drawing.Point(800, 6);
            this.lb_Category.Name = "lb_Category";
            this.lb_Category.Size = new System.Drawing.Size(137, 32);
            this.lb_Category.TabIndex = 1;
            this.lb_Category.Text = "Category";
            // 
            // lb_Detail
            // 
            this.lb_Detail.AutoSize = true;
            this.lb_Detail.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Detail.Location = new System.Drawing.Point(27, 446);
            this.lb_Detail.Name = "lb_Detail";
            this.lb_Detail.Size = new System.Drawing.Size(109, 32);
            this.lb_Detail.TabIndex = 2;
            this.lb_Detail.Text = "Details";
            // 
            // dataGridView_Product
            // 
            this.dataGridView_Product.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Product.Location = new System.Drawing.Point(3, 44);
            this.dataGridView_Product.Name = "dataGridView_Product";
            this.dataGridView_Product.RowHeadersVisible = false;
            this.dataGridView_Product.RowHeadersWidth = 62;
            this.dataGridView_Product.RowTemplate.Height = 28;
            this.dataGridView_Product.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Product.Size = new System.Drawing.Size(748, 392);
            this.dataGridView_Product.TabIndex = 3;
            this.dataGridView_Product.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Product_CellContentClick);
            // 
            // dataGridView_Category
            // 
            this.dataGridView_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView_Category.Location = new System.Drawing.Point(774, 44);
            this.dataGridView_Category.Name = "dataGridView_Category";
            this.dataGridView_Category.RowHeadersVisible = false;
            this.dataGridView_Category.RowHeadersWidth = 62;
            this.dataGridView_Category.RowTemplate.Height = 28;
            this.dataGridView_Category.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView_Category.Size = new System.Drawing.Size(298, 300);
            this.dataGridView_Category.TabIndex = 4;
            this.dataGridView_Category.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView_Category_CellContentClick);
            // 
            // lb_NamaDetails
            // 
            this.lb_NamaDetails.AutoSize = true;
            this.lb_NamaDetails.Location = new System.Drawing.Point(31, 478);
            this.lb_NamaDetails.Name = "lb_NamaDetails";
            this.lb_NamaDetails.Size = new System.Drawing.Size(59, 20);
            this.lb_NamaDetails.TabIndex = 5;
            this.lb_NamaDetails.Text = "Nama :";
            // 
            // lb_CategoryDetails
            // 
            this.lb_CategoryDetails.AutoSize = true;
            this.lb_CategoryDetails.Location = new System.Drawing.Point(5, 509);
            this.lb_CategoryDetails.Name = "lb_CategoryDetails";
            this.lb_CategoryDetails.Size = new System.Drawing.Size(85, 20);
            this.lb_CategoryDetails.TabIndex = 6;
            this.lb_CategoryDetails.Text = "Category : ";
            // 
            // lb_HargaDetails
            // 
            this.lb_HargaDetails.AutoSize = true;
            this.lb_HargaDetails.Location = new System.Drawing.Point(29, 544);
            this.lb_HargaDetails.Name = "lb_HargaDetails";
            this.lb_HargaDetails.Size = new System.Drawing.Size(61, 20);
            this.lb_HargaDetails.TabIndex = 7;
            this.lb_HargaDetails.Text = "Harga :";
            // 
            // lb_StockDetails
            // 
            this.lb_StockDetails.AutoSize = true;
            this.lb_StockDetails.Location = new System.Drawing.Point(31, 575);
            this.lb_StockDetails.Name = "lb_StockDetails";
            this.lb_StockDetails.Size = new System.Drawing.Size(62, 20);
            this.lb_StockDetails.TabIndex = 8;
            this.lb_StockDetails.Text = "Stock : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(802, 355);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "Nama :";
            // 
            // tb_NamaDetail
            // 
            this.tb_NamaDetail.Location = new System.Drawing.Point(97, 478);
            this.tb_NamaDetail.Name = "tb_NamaDetail";
            this.tb_NamaDetail.Size = new System.Drawing.Size(470, 26);
            this.tb_NamaDetail.TabIndex = 10;
            // 
            // tb_HargaDetails
            // 
            this.tb_HargaDetails.Location = new System.Drawing.Point(97, 544);
            this.tb_HargaDetails.Name = "tb_HargaDetails";
            this.tb_HargaDetails.Size = new System.Drawing.Size(141, 26);
            this.tb_HargaDetails.TabIndex = 11;
            // 
            // tb_StockDetails
            // 
            this.tb_StockDetails.Location = new System.Drawing.Point(97, 576);
            this.tb_StockDetails.Name = "tb_StockDetails";
            this.tb_StockDetails.Size = new System.Drawing.Size(141, 26);
            this.tb_StockDetails.TabIndex = 12;
            // 
            // comboBox_CategoryDetails
            // 
            this.comboBox_CategoryDetails.FormattingEnabled = true;
            this.comboBox_CategoryDetails.Location = new System.Drawing.Point(97, 511);
            this.comboBox_CategoryDetails.Name = "comboBox_CategoryDetails";
            this.comboBox_CategoryDetails.Size = new System.Drawing.Size(141, 28);
            this.comboBox_CategoryDetails.TabIndex = 13;
            this.comboBox_CategoryDetails.SelectedIndexChanged += new System.EventHandler(this.comboBox_CategoryDetails_SelectedIndexChanged);
            // 
            // tb_NamaCategory
            // 
            this.tb_NamaCategory.Location = new System.Drawing.Point(890, 355);
            this.tb_NamaCategory.Name = "tb_NamaCategory";
            this.tb_NamaCategory.Size = new System.Drawing.Size(182, 26);
            this.tb_NamaCategory.TabIndex = 14;
            // 
            // comboBox_Filter
            // 
            this.comboBox_Filter.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox_Filter.Enabled = false;
            this.comboBox_Filter.FormattingEnabled = true;
            this.comboBox_Filter.Location = new System.Drawing.Point(493, 12);
            this.comboBox_Filter.Name = "comboBox_Filter";
            this.comboBox_Filter.Size = new System.Drawing.Size(141, 28);
            this.comboBox_Filter.TabIndex = 15;
            this.comboBox_Filter.SelectedIndexChanged += new System.EventHandler(this.comboBox_Filter_SelectedIndexChanged);
            // 
            // bt_Filter
            // 
            this.bt_Filter.Location = new System.Drawing.Point(412, 11);
            this.bt_Filter.Name = "bt_Filter";
            this.bt_Filter.Size = new System.Drawing.Size(75, 29);
            this.bt_Filter.TabIndex = 16;
            this.bt_Filter.Text = "Filter";
            this.bt_Filter.UseVisualStyleBackColor = true;
            this.bt_Filter.Click += new System.EventHandler(this.bt_Filter_Click);
            // 
            // bt_All
            // 
            this.bt_All.Location = new System.Drawing.Point(331, 12);
            this.bt_All.Name = "bt_All";
            this.bt_All.Size = new System.Drawing.Size(75, 29);
            this.bt_All.TabIndex = 17;
            this.bt_All.Text = "All";
            this.bt_All.UseVisualStyleBackColor = true;
            this.bt_All.Click += new System.EventHandler(this.bt_All_Click);
            // 
            // bt_AddProduct
            // 
            this.bt_AddProduct.Location = new System.Drawing.Point(267, 526);
            this.bt_AddProduct.Name = "bt_AddProduct";
            this.bt_AddProduct.Size = new System.Drawing.Size(87, 76);
            this.bt_AddProduct.TabIndex = 18;
            this.bt_AddProduct.Text = "Add Product";
            this.bt_AddProduct.UseVisualStyleBackColor = true;
            this.bt_AddProduct.Click += new System.EventHandler(this.bt_AddProduct_Click);
            // 
            // bt_EditProduct
            // 
            this.bt_EditProduct.Location = new System.Drawing.Point(360, 526);
            this.bt_EditProduct.Name = "bt_EditProduct";
            this.bt_EditProduct.Size = new System.Drawing.Size(86, 76);
            this.bt_EditProduct.TabIndex = 19;
            this.bt_EditProduct.Text = "Edit Product";
            this.bt_EditProduct.UseVisualStyleBackColor = true;
            this.bt_EditProduct.Click += new System.EventHandler(this.bt_EditProduct_Click);
            // 
            // bt_RemoveProduct
            // 
            this.bt_RemoveProduct.Location = new System.Drawing.Point(452, 526);
            this.bt_RemoveProduct.Name = "bt_RemoveProduct";
            this.bt_RemoveProduct.Size = new System.Drawing.Size(92, 76);
            this.bt_RemoveProduct.TabIndex = 20;
            this.bt_RemoveProduct.Text = "Remove Product";
            this.bt_RemoveProduct.UseVisualStyleBackColor = true;
            this.bt_RemoveProduct.Click += new System.EventHandler(this.bt_RemoveProduct_Click);
            // 
            // bt_AddCategory
            // 
            this.bt_AddCategory.Location = new System.Drawing.Point(864, 387);
            this.bt_AddCategory.Name = "bt_AddCategory";
            this.bt_AddCategory.Size = new System.Drawing.Size(102, 49);
            this.bt_AddCategory.TabIndex = 21;
            this.bt_AddCategory.Text = "Add Category";
            this.bt_AddCategory.UseVisualStyleBackColor = true;
            this.bt_AddCategory.Click += new System.EventHandler(this.bt_AddCategory_Click);
            // 
            // bt_RemoveCategory
            // 
            this.bt_RemoveCategory.Location = new System.Drawing.Point(972, 387);
            this.bt_RemoveCategory.Name = "bt_RemoveCategory";
            this.bt_RemoveCategory.Size = new System.Drawing.Size(100, 53);
            this.bt_RemoveCategory.TabIndex = 22;
            this.bt_RemoveCategory.Text = "Remove Category";
            this.bt_RemoveCategory.UseVisualStyleBackColor = true;
            this.bt_RemoveCategory.Click += new System.EventHandler(this.bt_RemoveCategory_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::tugas_W05.Properties.Resources.Screenshot_2024_03_26_220558;
            this.pictureBox1.Location = new System.Drawing.Point(594, 446);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(593, 213);
            this.pictureBox1.TabIndex = 23;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.ClientSize = new System.Drawing.Size(1199, 667);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.bt_RemoveCategory);
            this.Controls.Add(this.bt_AddCategory);
            this.Controls.Add(this.bt_RemoveProduct);
            this.Controls.Add(this.bt_EditProduct);
            this.Controls.Add(this.bt_AddProduct);
            this.Controls.Add(this.bt_All);
            this.Controls.Add(this.bt_Filter);
            this.Controls.Add(this.comboBox_Filter);
            this.Controls.Add(this.tb_NamaCategory);
            this.Controls.Add(this.comboBox_CategoryDetails);
            this.Controls.Add(this.tb_StockDetails);
            this.Controls.Add(this.tb_HargaDetails);
            this.Controls.Add(this.tb_NamaDetail);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lb_StockDetails);
            this.Controls.Add(this.lb_HargaDetails);
            this.Controls.Add(this.lb_CategoryDetails);
            this.Controls.Add(this.lb_NamaDetails);
            this.Controls.Add(this.dataGridView_Category);
            this.Controls.Add(this.dataGridView_Product);
            this.Controls.Add(this.lb_Detail);
            this.Controls.Add(this.lb_Category);
            this.Controls.Add(this.lb_Product);
            this.Name = "Form1";
            this.Text = "Toko_BlekPink";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Product)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_Product;
        private System.Windows.Forms.Label lb_Category;
        private System.Windows.Forms.Label lb_Detail;
        private System.Windows.Forms.DataGridView dataGridView_Product;
        private System.Windows.Forms.DataGridView dataGridView_Category;
        private System.Windows.Forms.Label lb_NamaDetails;
        private System.Windows.Forms.Label lb_CategoryDetails;
        private System.Windows.Forms.Label lb_HargaDetails;
        private System.Windows.Forms.Label lb_StockDetails;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tb_NamaDetail;
        private System.Windows.Forms.TextBox tb_HargaDetails;
        private System.Windows.Forms.TextBox tb_StockDetails;
        private System.Windows.Forms.ComboBox comboBox_CategoryDetails;
        private System.Windows.Forms.TextBox tb_NamaCategory;
        private System.Windows.Forms.ComboBox comboBox_Filter;
        private System.Windows.Forms.Button bt_Filter;
        private System.Windows.Forms.Button bt_All;
        private System.Windows.Forms.Button bt_AddProduct;
        private System.Windows.Forms.Button bt_EditProduct;
        private System.Windows.Forms.Button bt_RemoveProduct;
        private System.Windows.Forms.Button bt_AddCategory;
        private System.Windows.Forms.Button bt_RemoveCategory;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

