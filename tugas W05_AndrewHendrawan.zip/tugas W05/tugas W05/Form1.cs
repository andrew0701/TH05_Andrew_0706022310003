﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tugas_W05
{
    public partial class Form1 : Form
    {
        string idproduct = "";
        int idcategory = -1;
        bool hapus = false;
        bool delete = false;
        DataTable dt_ProductMuncul = new DataTable();
        DataTable dt_Category = new DataTable();
        DataTable dt_ProductSimpanan = new DataTable();
        bool jadi = false;

        public Form1()
        {
            InitializeComponent();

            dt_ProductMuncul.Columns.Add("ID Product");
            dt_ProductMuncul.Columns.Add("Nama Product");
            dt_ProductMuncul.Columns.Add("Harga");
            dt_ProductMuncul.Columns.Add("Stock");
            dt_ProductMuncul.Columns.Add("ID Category");
            dt_ProductMuncul.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dt_ProductMuncul.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dt_ProductMuncul.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dt_ProductMuncul.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dt_ProductMuncul.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dt_ProductMuncul.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dt_ProductMuncul.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dt_ProductMuncul.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dataGridView_Product.DataSource = dt_ProductMuncul;

            

            dt_Category.Columns.Add("ID Category");
            dt_Category.Columns.Add("Nama Category");
            dt_Category.Rows.Add("C1", "Jas");
            dt_Category.Rows.Add("C2", "T-Shirt");
            dt_Category.Rows.Add("C3", "Rok");
            dt_Category.Rows.Add("C4", "Celana");
            dt_Category.Rows.Add("C5", "Cawat");

            dataGridView_Category.DataSource = dt_Category;

            

            dt_ProductSimpanan.Columns.Add("ID Product");
            dt_ProductSimpanan.Columns.Add("Nama Product");
            dt_ProductSimpanan.Columns.Add("Harga");
            dt_ProductSimpanan.Columns.Add("Stock");
            dt_ProductSimpanan.Columns.Add("ID Category");
            dt_ProductSimpanan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dt_ProductSimpanan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dt_ProductSimpanan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dt_ProductSimpanan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dt_ProductSimpanan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dt_ProductSimpanan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dt_ProductSimpanan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dt_ProductSimpanan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");

            dataGridView_Product.AllowUserToAddRows = false;
            dataGridView_Category.AllowUserToDeleteRows = false;

            for (int i = 0; i < dt_ProductSimpanan.Rows.Count; i++)
            {
                string id = dt_ProductSimpanan.Rows[i][0].ToString();
                string nama = dt_ProductSimpanan.Rows[i][1].ToString();
                string harga = dt_ProductSimpanan.Rows[i][2].ToString();
                string stock = dt_ProductSimpanan.Rows[i][3].ToString();
                string category = dt_ProductSimpanan.Rows[i][4].ToString();
                dt_ProductMuncul.Rows.Add(id,nama,harga,stock,category);
            }
            dataGridView_Product.DataSource = dt_ProductMuncul;
            dataGridView_Category.DataSource = dt_Category;
            comboBox_CategoryDetails.Items.Clear();
            comboBox_Filter.Items.Clear();
            for (int i = 0; i < dt_Category.Rows.Count; i++)
            {
                comboBox_CategoryDetails.Items.Add(dt_Category.Rows[i][1].ToString());
                comboBox_Filter.Items.Add(dt_Category.Rows[i][1].ToString());
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //comboBox_CategoryDetails.Items.Add("Jas");
            //comboBox_CategoryDetails.Items.Add("T-Shirt");
            //comboBox_CategoryDetails.Items.Add("Rok");
            //comboBox_CategoryDetails.Items.Add("Celana");
            //comboBox_CategoryDetails.Items.Add("Cawat");
            //comboBox_CategoryDetails.Items.Add(tb_NamaCategory.Text);
            dataGridView_Category.ClearSelection();
            dataGridView_Product.ClearSelection();
            this.BackColor = Color.Orange;

        }

        private void bt_AddProduct_Click(object sender, EventArgs e)
        {
            if (tb_NamaDetail.Text == "" && tb_HargaDetails.Text == "" && tb_StockDetails.Text == "" && idcategory == -1)
            {
                MessageBox.Show("Gagal Dimasukan");
            }
            else if (tb_NamaDetail.Text != "" && tb_HargaDetails.Text != "" && tb_StockDetails.Text != "" && idcategory != -1)
            {
                string hurufpalingdepan = tb_NamaDetail.Text.Substring(0, 1).ToUpper();
                int countid = 0;
                for (int j = 0; j < dt_ProductSimpanan.Rows.Count; j++)
                {
                    if (dt_ProductSimpanan.Rows[j][0].ToString().Contains(hurufpalingdepan + "00"))
                    {
                        countid = Convert.ToInt32(dt_ProductSimpanan.Rows[j][0].ToString().Substring(3, 1));
                    }
                    else if (dt_ProductSimpanan.Rows[j][0].ToString().Contains(hurufpalingdepan + "0"))
                    {
                        countid = Convert.ToInt32(dt_ProductSimpanan.Rows[j][0].ToString().Substring(2, 2));
                    }
                    else if (dt_ProductSimpanan.Rows[j][0].ToString().Substring(0, 1) == hurufpalingdepan)
                    {
                        countid = Convert.ToInt32(dt_ProductSimpanan.Rows[j][0].ToString().Substring(1, 3));
                    }
                }
                string aid = "";
                countid = countid +1;
                if (countid < 10)
                {
                    aid = hurufpalingdepan + "00" + countid.ToString();
                }
                else if (countid < 100)
                {
                    aid = hurufpalingdepan + "0" + countid.ToString();
                }
                else
                {
                    aid = hurufpalingdepan + countid.ToString();
                }
                string anama = tb_NamaDetail.Text;
                string acategory = dt_Category.Rows[idcategory][0].ToString();
                string aharga = tb_HargaDetails.Text;
                string astock = tb_StockDetails.Text;
                dt_ProductSimpanan.Rows.Add(aid, anama, aharga, astock, acategory);
                dt_ProductMuncul.Clear();
                for (int c = 0; c < dt_ProductSimpanan.Rows.Count; c++)
                {
                    string id = dt_ProductSimpanan.Rows[c][0].ToString();
                    string nama = dt_ProductSimpanan.Rows[c][1].ToString();
                    string category = dt_ProductSimpanan.Rows[c][4].ToString();
                    string harga = dt_ProductSimpanan.Rows[c][2].ToString();
                    string stock = dt_ProductSimpanan.Rows[c][3].ToString();
                    dt_ProductMuncul.Rows.Add(id, nama, harga, stock, category);
                }
                tb_NamaDetail.Text = "";
                tb_HargaDetails.Text = "";
                tb_StockDetails.Text = "";
                comboBox_CategoryDetails.SelectedIndex = -1;
                idcategory = -1;
            }
        }

        private void bt_EditProduct_Click(object sender, EventArgs e)
        {
            if (tb_NamaDetail.Text == "" && tb_HargaDetails.Text == "" && tb_StockDetails.Text == "" && idcategory == -1)
            {
                MessageBox.Show("Gagal Diedit");
            }
            else if (tb_NamaDetail.Text != "" && tb_HargaDetails.Text != "" && tb_StockDetails.Text != "" && idcategory != -1)
            {
                int keberapa = dataGridView_Product.CurrentCell.RowIndex;
                string idbarang = dt_ProductMuncul.Rows[keberapa][0].ToString();
                string anama = tb_NamaDetail.Text;
                string acategory = dt_Category.Rows[idcategory][0].ToString();
                string aharga = tb_HargaDetails.Text;
                string astock = tb_StockDetails.Text;
                for (int c = 0; c < dt_ProductSimpanan.Rows.Count; c++)
                {
                    if (dt_ProductSimpanan.Rows[c][0].ToString() == idbarang)
                    {
                        dt_ProductSimpanan.Rows[c][1] = anama;
                        dt_ProductSimpanan.Rows[c][4] = acategory;
                        dt_ProductSimpanan.Rows[c][2] = aharga;
                        dt_ProductSimpanan.Rows[c][3] = astock;
                        jadi = true;
                        break;
                    }
                }
                dt_ProductMuncul.Clear();
                for (int d = 0; d < dt_ProductSimpanan.Rows.Count; d++)
                {
                    string id = dt_ProductSimpanan.Rows[d][0].ToString();
                    string nama = dt_ProductSimpanan.Rows[d][1].ToString();
                    string category = dt_ProductSimpanan.Rows[d][4].ToString();
                    string harga = dt_ProductSimpanan.Rows[d][2].ToString();
                    string stock = dt_ProductSimpanan.Rows[d][3].ToString();
                    dt_ProductMuncul.Rows.Add(id, nama, harga, stock, category);
                }
                tb_HargaDetails.Text = "";
                tb_NamaDetail.Text = "";
                tb_StockDetails.Text = "";
                idcategory = -1;
                comboBox_CategoryDetails.SelectedItem = -1;
            }
        }

        private void bt_RemoveProduct_Click(object sender, EventArgs e)
        {
            if (tb_NamaDetail.Text == "" && tb_HargaDetails.Text == "" && tb_StockDetails.Text == ""  && idcategory == -1 && delete)
            {

            }
            if (tb_NamaDetail.Text != "" && tb_HargaDetails.Text != "" && tb_StockDetails.Text != ""  && idcategory != -1 && delete)
            {
                int keberapa = dataGridView_Product.CurrentCell.RowIndex;
                string IDbarang = dt_ProductMuncul.Rows[keberapa][0].ToString();
                for (int d = 0; d < dt_ProductSimpanan.Rows.Count; d++)
                {
                    if (dt_ProductSimpanan.Rows[d][0].ToString() == IDbarang)
                    {
                        dt_ProductSimpanan.Rows[d].Delete();
                        break;
                    }
                }
                dt_ProductMuncul.Clear();
                for (int f = 0; f < dt_ProductSimpanan.Rows.Count; f++)
                {
                    string id4 = dt_ProductSimpanan.Rows[f][0].ToString();
                    string nama4 = dt_ProductSimpanan.Rows[f][1].ToString();
                    string category4 = dt_ProductSimpanan.Rows[f][4].ToString();
                    string harga4 = dt_ProductSimpanan.Rows[f][2].ToString();
                    string stock4 = dt_ProductSimpanan.Rows[f][3].ToString();
                    dt_ProductMuncul.Rows.Add(id4, nama4, harga4, stock4, category4);
                }
                tb_NamaCategory.Text = "";
                tb_HargaDetails.Text = "";
                tb_StockDetails.Text = "";
                comboBox_CategoryDetails.SelectedItem = -1;
                idcategory = -1;
                delete = false;
            }
            else
            {
                MessageBox.Show("Pilih yang ingin dihapus");
            }
        }

        private void bt_AddCategory_Click(object sender, EventArgs e)
        {
            if (tb_NamaCategory.Text == "")
            {
                MessageBox.Show("Masukan nama");
            }
            else if (tb_NamaCategory.Text != "")
            {
                bool ada = true;
                for (int g = 0; g < dt_Category.Rows.Count; g++)
                {
                    if (tb_NamaCategory.Text == dt_Category.Rows[g][1].ToString())
                    {
                        ada = false;
                        break;
                    }
                }
                if (ada)
                {
                    int newid = 0;
                    if (dt_Category.Rows[dt_Category.Rows.Count - 1][0].ToString().Length == 2)
                    {
                        newid = Convert.ToInt32(dt_Category.Rows[dt_Category.Rows.Count - 1][0].ToString().Substring(1, 1));
                    }
                    else if (dt_Category.Rows[dt_Category.Rows.Count - 1][0].ToString().Length == 3)
                    {
                        newid = Convert.ToInt32(dt_Category.Rows[dt_Category.Rows.Count - 1][0].ToString().Substring(1, 2));
                    }
                    else
                    {
                        newid = Convert.ToInt32(dt_Category.Rows[dt_Category.Rows.Count - 1][0].ToString().Substring(1, 3));
                    }
                    newid = newid+ 1;
                    string newid2 = "C" + newid.ToString();
                    dt_Category.Rows.Add(newid2, tb_NamaCategory.Text);
                }
                else
                {
                    MessageBox.Show("udah ada");
                }
                comboBox_CategoryDetails.Items.Clear();
                comboBox_Filter.Items.Clear();
                for (int h = 0; h < dt_Category.Rows.Count; h++)
                {
                    comboBox_CategoryDetails.Items.Add(dt_Category.Rows[h][1].ToString());
                    comboBox_Filter.Items.Add(dt_Category.Rows[h][1].ToString());
                }
                comboBox_Filter.SelectedIndex = -1;
                comboBox_CategoryDetails.SelectedIndex = -1;
                dt_ProductMuncul.Clear();
                for (int i = 0; i < dt_Category.Rows.Count; i++)
                {
                    string id5 = dt_ProductSimpanan.Rows[i][0].ToString();
                    string nama5 = dt_ProductSimpanan.Rows[i][1].ToString();
                    string category5 = dt_ProductSimpanan.Rows[i][4].ToString();
                    string harga5 = dt_ProductSimpanan.Rows[i][2].ToString();
                    string stock5 = dt_ProductSimpanan.Rows[i][3].ToString();
                    dt_ProductMuncul.Rows.Add(id5, nama5, harga5, stock5, category5);
                }
                tb_NamaDetail.Text = "";
                tb_HargaDetails.Text = "";
                tb_StockDetails.Text = "";
                idcategory = -1;
            }
        }

        private void bt_Filter_Click(object sender, EventArgs e)
        {
            comboBox_Filter.Enabled = true ;
        }

        private void bt_All_Click(object sender, EventArgs e)
        {
            comboBox_Filter.Enabled = false;
            comboBox_Filter.SelectedIndex = -1;
            dt_ProductMuncul.Clear();
            for (int a = 0; a< dt_ProductSimpanan.Rows.Count; a++)
            {
                string id2 = dt_ProductSimpanan.Rows[a][0].ToString();
                string nama2 = dt_ProductSimpanan.Rows[a][1].ToString();
                string category2 = dt_ProductSimpanan.Rows[a][4].ToString();
                string harga2 = dt_ProductSimpanan.Rows[a][2].ToString();
                string stock2 = dt_ProductSimpanan.Rows[a][3].ToString();
                dt_ProductMuncul.Rows.Add(id2, nama2, harga2, stock2, category2);
            }
        }
        private void comboBox_Filter_SelectedIndexChanged(object sender, EventArgs e)
        {
            //comboBox_Filter.Enabled = false;
            //comboBox_Filter.SelectedIndex = -1;
            //dt_ProductMuncul.Clear();
            //for (int b = 0; b < dt_ProductSimpanan.Rows.Count; b++) 
            //{
            //    string id = dt_ProductSimpanan.Rows[b][0].ToString();
            //    string nama = dt_ProductSimpanan.Rows[b][1].ToString();
            //    string harga = dt_ProductSimpanan.Rows[b][2].ToString();
            //    string stock = dt_ProductSimpanan.Rows[b][3].ToString();
            //    string category = dt_ProductSimpanan.Rows[b][4].ToString();
            //    dt_ProductMuncul.Rows.Add(id, nama, harga, stock, category);
            //}
        }
        private void comboBox_CategoryDetails_SelectedIndexChanged(object sender, EventArgs e)
        {
            idcategory = comboBox_CategoryDetails.SelectedIndex;
        }

        private void bt_RemoveCategory_Click(object sender, EventArgs e)
        {
            if (tb_NamaCategory.Text == "")
            {
                MessageBox.Show("pilih baris");
            }
            else if (tb_NamaCategory.Text != "" && hapus)
            {
                for (int k = 0; k < dt_ProductSimpanan.Rows.Count; k++)
                {
                    if (dt_ProductSimpanan.Rows[k][4].ToString() == dt_Category.Rows[dataGridView_Category.CurrentCell.RowIndex][0].ToString())
                    {
                        dt_ProductSimpanan.Rows[k].Delete();
                        k = 0;
                    }
                }
                dt_Category.Rows[dataGridView_Category.CurrentCell.RowIndex].Delete();
                comboBox_CategoryDetails.SelectedIndex = -1;
                comboBox_Filter.SelectedIndex = -1;
                for (int l = 0; l < dt_ProductSimpanan.Rows.Count; l++)
                {
                    string id6 = dt_ProductSimpanan.Rows[l][0].ToString();
                    string nama6 = dt_ProductSimpanan.Rows[l][1].ToString();
                    string harga6 = dt_ProductSimpanan.Rows[l][2].ToString();
                    string stock6 = dt_ProductSimpanan.Rows[l][3].ToString();
                    string category6 = dt_ProductSimpanan.Rows[l][4].ToString();
                    dt_ProductMuncul.Rows.Add(id6, nama6, harga6, stock6, category6);
                }
                comboBox_Filter.Items.Clear();
                comboBox_CategoryDetails.Items.Clear();
                for (int m = 0; m < dt_Category.Rows.Count; m++)
                {
                    comboBox_Filter.Items.Add(dt_Category.Rows[m][1].ToString());
                    comboBox_CategoryDetails.Items.Add(dt_Category.Rows[m][1].ToString());
                }
                hapus = false;
                tb_NamaDetail.Text = "";
                tb_HargaDetails.Text = "";
                tb_StockDetails.Text = "";
                idcategory = -1;
            }
        }
        private void dataGridView_Category_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int indeks = dataGridView_Category.CurrentCell.RowIndex;
            tb_NamaCategory.Text = dt_Category.Rows[indeks][1].ToString();
            hapus = true;
        }
        private void dataGridView_Product_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int Keberapa = dataGridView_Product.CurrentCell.RowIndex;
            delete = true;
            idproduct = dt_ProductMuncul.Rows[Keberapa][0].ToString();
            string nama = dt_ProductMuncul.Rows[Keberapa][1].ToString();
            string category = dt_ProductSimpanan.Rows[Keberapa][4].ToString();
            string harga = dt_ProductSimpanan.Rows[Keberapa][2].ToString();
            string stock = dt_ProductSimpanan.Rows[Keberapa][3].ToString();
            tb_NamaDetail.Text = nama;
            tb_StockDetails.Text = stock;
            tb_HargaDetails.Text = harga;
            idcategory = -1;
            for (int i = 0; i < dt_Category.Rows.Count; i++)
            {
                if (dt_Category.Rows[i][0].ToString() == category)
                {
                    comboBox_CategoryDetails.SelectedIndex = i;
                    idcategory = i;
                    break;
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
